#include <stdio.h>
#include <stdbool.h>

typedef enum { MOTORCYCLE, CAR, VAN, TRUCK } TVehicles;
typedef enum {MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY }DaysOfTheWeek;

int main () {
	bool isAnElectricVehicle;
	int numberofPassengers; 
	TVehicles vehicleType; 
	DaysOfTheWeek dayOfWeek; 
	// OUTPUT
	
	bool hasDiscount;
	
	printf ("Enter number of passengers: ");
	scanf  ( "%d", &numberofPassengers);
	
	printf ("Is an electric vehicle? (1:Yes, 0:No) :");
	scanf ("%d" , &isAnElectricVehicle);
	
	printf ("Enter vehicle type (0:Motorcycle, 1:Car, 2:Van, 3:Truck):");
	scanf ("%d" , &vehicleType);
	
	printf ("Enter day of the week (0:Monday to 6:Sunday): ");
	scanf ("%d", &dayOfWeek);
	
	hasDiscount = (
	((vehicleType == MOTORCYCLE || vehicleType == VAN || vehicleType == CAR) && (dayOfWeek == MONDAY || dayOfWeek == TUESDAY)) ||
	(vehicleType == TRUCK && (dayOfWeek >= MONDAY && dayOfWeek <= FRIDAY)) 
	|| (vehicleType == CAR && numberofPassengers >=4) || isAnElectricVehicle
	);
	
	printf ("Has toll discount? (1:Yes, 0:No): %d\n" , hasDiscount);
	
	return 0;
}


